//
//  StudentModel.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 12/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import Foundation

class StudentModel
{
    var name: String = ""
    var batch: String = ""
    var age: Int = 0
    var id: Int = 0
    init(id:Int, name:String, age:Int, batch:String)
    {
        self.id = id
        self.name = name
        self.age = age
        self.batch = batch
    }
}
