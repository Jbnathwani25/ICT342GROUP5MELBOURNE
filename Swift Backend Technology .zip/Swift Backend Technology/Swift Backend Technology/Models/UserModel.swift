//
//  UserModel.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 12/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import Foundation

class UserModel
{
    var email: String = ""
    var password: String = ""
    var id: Int = 0
    init(id:Int, email:String, password:String)
    {
        self.id = id
        self.email = email
        self.password = password
    }
}
