//
//  StudentTableCell.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 13/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import UIKit

class StudentTableCell: UITableViewCell {

    @IBOutlet weak var labelAge: UILabel!
    @IBOutlet weak var labelBatch: UILabel!
    @IBOutlet weak var labelName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
