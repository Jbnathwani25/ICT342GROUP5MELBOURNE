//
//  Constants.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 12/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import Foundation

var kUserdefaultKeyIsSigneIn: String! = "UserdefaultKeyIsSigneIn"
