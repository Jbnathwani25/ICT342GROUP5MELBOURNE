//
//  ViewController.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 11/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import UIKit

class LoginViewController: BaseViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.isHidden = true
        //let db:DatabaseManager = DatabaseManager()
        // Do any additional setup after loading the view.
    }


    override  func viewWillAppear(_ animated: Bool) {
        checkIfLoggedIn()
        super.viewWillAppear(animated)
    }
    //    textfield Delegates
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    @IBAction func signInClicked(_ sender: Any) {
        CommonMethods.saveUserDefaultBool(value: true, key: kUserdefaultKeyIsSigneIn)
        self.performSegue(withIdentifier: "homeControllerSegue", sender: self);
    }
    func checkIfLoggedIn() {
        if(CommonMethods.getUserDefaultBool(key: kUserdefaultKeyIsSigneIn)){
            self.performSegue(withIdentifier: "homeControllerSegue", sender: self);
        }
        else {
            self.view.isHidden = false
        }
    }
}

