//
//  HomeViewController.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 12/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import UIKit
import Foundation
class HomeViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var tableViewStudents: UITableView!
    var arrayStudents: Array<StudentModel>! = []
    override func viewDidLoad() {
        super.viewDidLoad()
        let db:DatabaseManager = DatabaseManager()
        arrayStudents.append(contentsOf: db.getAllStudents())
        tableViewStudents.tableFooterView = UIView()

//        tableViewStudents.register(StudentTableCell.self, forCellReuseIdentifier: "StudentTableCellIdentifier")
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override  func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    @IBAction func signoutUser(_ sender: Any) {
        CommonMethods.showAlert(viewController: self, title: "Are you sure you want to signout?", message: "", okButtonTitle: "Signout", cancelbuttonTitle: "Cancel", actionPressed: { (buttonTitle) in
            if buttonTitle == "Signout"{
                self.navigationController?.popToRootViewController(animated: true)
                CommonMethods.saveUserDefaultBool(value: false, key: kUserdefaultKeyIsSigneIn)
            }
        })
    }
    //    Tableview methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return arrayStudents.count
      }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : StudentTableCell = tableViewStudents.dequeueReusableCell(withIdentifier: "StudentTableCellIdentifier", for: indexPath) as! StudentTableCell
        let student = arrayStudents[indexPath.row]
        cell.labelName.text = student.name 
        cell.labelBatch.text = student.batch 
        cell.labelAge.text = String(student.age) 
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           print("You tapped cell number \(indexPath.row).")
       }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "ViewStudentIdentifier", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(sender is HomeViewController)
        {
            let addStudentController = segue.destination as! AddStudentController
            addStudentController.titleString = "Details"
            addStudentController.studentModel = arrayStudents[tableViewStudents.indexPathForSelectedRow?.row ?? 0]
        }
    }
}
