//
//  AddStudentController.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 12/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import UIKit
import Foundation
class AddStudentController: BaseViewController, UITextFieldDelegate {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var batchTextField: UITextField!
    var titleString: String?
    var studentModel: StudentModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override  func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    func loadData() {
        self.navigationItem.title = titleString ?? "Add Student"
    }
    
    //    textfield Delegates
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
              return false
    }
    @IBAction func addStudent(_ sender: Any) {
        let db:DatabaseManager = DatabaseManager()
//        db.insertStudentDetails(id: 0, name: nameTextField.text ?? "", age: Int(ageTextField?.text ?? "") ?? 0, batch: batchTextField.text ?? "")
        db.insertStudentDetails(id: 0, name: "Akash", age: 30, batch: "CS")
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func goBack(_ sender: Any) {
        CommonMethods.showAlert(viewController: self, title: "Are you sure you want to cancel?", message: "", okButtonTitle: "Yes", cancelbuttonTitle: "No") { (buttonTitle) in
            if(buttonTitle == "Yes"){
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
}
