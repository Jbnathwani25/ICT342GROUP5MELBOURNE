//
//  RegisterViewController.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 11/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import UIKit

class RegisterViewController: BaseViewController, UITextFieldDelegate {
    @IBOutlet weak var userEmailTextField: UITextField!
    @IBOutlet weak var userPasswordTextField: UITextField!
    @IBOutlet weak var repeatPasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func registerButtonTapped(_ sender: AnyObject) {
        
        let userEmail = userEmailTextField.text;
        let userPassword = userPasswordTextField.text;
        let userRepeatPassword = repeatPasswordTextField.text;
    
        if (userEmail!.isEmpty || userPassword!.isEmpty || userRepeatPassword!.isEmpty)
        {
            CommonMethods.showAlert(viewController: self, title: "Failed!", message: "Please fill all fields.", okButtonTitle: "Ok", cancelbuttonTitle: "") { (buttonTitle) in
            }
        }
        else if (userPassword != userRepeatPassword)
        {
            CommonMethods.showAlert(viewController: self, title:"Failed!", message: "Passwords do not match!", okButtonTitle: "Ok", cancelbuttonTitle: "") { (buttonTitle) in
                    }
            return;
        }
    }

    @IBAction func goBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func gotoLogin(_ sender: Any) {
        goBack(sender)
    }
//    textfield Delegates
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
              return false
    }

}
