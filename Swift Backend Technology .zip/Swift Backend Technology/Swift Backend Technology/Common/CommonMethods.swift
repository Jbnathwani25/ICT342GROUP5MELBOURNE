//
//  CommonMethods.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 12/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import Foundation
import UIKit
class CommonMethods: NSObject {
    class func showAlert(viewController:UIViewController, title:String, message: String, okButtonTitle:String, cancelbuttonTitle:String ,actionPressed: @escaping (_ buttonTitle:String) -> Void){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        if(!cancelbuttonTitle.isEmpty)
        {
            alert.addAction(UIAlertAction(title: cancelbuttonTitle, style: UIAlertAction.Style.cancel, handler: { action in
                actionPressed(cancelbuttonTitle)
            }))
        }
        if(!okButtonTitle.isEmpty)
        {
            alert.addAction(UIAlertAction(title: okButtonTitle, style: UIAlertAction.Style.default, handler: { action in
                actionPressed(okButtonTitle)
            }))
        }
        viewController.present(alert, animated: true, completion: nil)
    }
    class func saveUserDefaultBool(value:Bool, key:String)
    {
        UserDefaults.standard.set(value, forKey: key)
        UserDefaults.standard.synchronize()
    }
    class func getUserDefaultBool(key:String) ->(Bool)
    {
        return UserDefaults.standard.bool(forKey: key)
    }
    class func addKeyboardDismissGesture(view:UIView){
       let dismissGesture = UITapGestureRecognizer.init(target: view, action: #selector(view.endEditing(_:)))
        view.addGestureRecognizer(dismissGesture)
    }
}
