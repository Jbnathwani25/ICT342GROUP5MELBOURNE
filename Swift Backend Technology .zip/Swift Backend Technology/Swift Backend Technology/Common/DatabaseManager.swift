//
//  DatabaseManager.swift
//  Swift Backend Technology
//
//  Created by ABY FRANCIS on 12/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import Foundation
import SQLite3

class DatabaseManager
{
    init()
    {
        db = openDatabase()
        createStudentsTable()
        createUsersTable()
    }

    let dbPath: String = "database.sqlite"
    var db:OpaquePointer?
    func openDatabase() -> OpaquePointer?
    {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent(dbPath)
        var db: OpaquePointer? = nil
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK
        {
            print("error opening database")
            return nil
        }
        else
        {
            print("Successfully opened connection to database at \(dbPath)")
            return db
        }
    }
    func createStudentsTable() {
        let createTableString = "CREATE TABLE IF NOT EXISTS Student(Id INTEGER PRIMARY KEY, name TEXT,age INTEGER, batch TEXT);"
        var createTableStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, createTableString, -1, &createTableStatement, nil) == SQLITE_OK
        {
            if sqlite3_step(createTableStatement) == SQLITE_DONE
            {
                print("Student table created.")
            } else {
                print("Student table could not be created.")
            }
        } else {
            print("CREATE TABLE statement could not be prepared.")
        }
        sqlite3_finalize(createTableStatement)
    }
    func createUsersTable() {
          let createTableString = "CREATE TABLE IF NOT EXISTS User(Id INTEGER PRIMARY KEY, email TEXT,password TEXT);"
          var createTableStatement: OpaquePointer? = nil
          if sqlite3_prepare_v2(db, createTableString, -1, &createTableStatement, nil) == SQLITE_OK
          {
              if sqlite3_step(createTableStatement) == SQLITE_DONE
              {
                  print("User table created.")
              } else {
                  print("User table could not be created.")
              }
          } else {
              print("CREATE TABLE statement could not be prepared.")
          }
          sqlite3_finalize(createTableStatement)
      }
    func insertStudentDetails(id:Int, name:String, age:Int, batch:String)
    {
        let persons = getAllStudents()
        for p in persons
        {
            if p.id == id
            {
                return
            }
        }
        let insertStatementString = "INSERT INTO Student (Id, name, age, batch) VALUES (NULL, ?, ?, ?);"
        var insertStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
            sqlite3_bind_text(insertStatement, 1, (name as NSString).utf8String, -1, nil)
            sqlite3_bind_int(insertStatement, 2, Int32(age))
            sqlite3_bind_text(insertStatement, 3, (batch as NSString).utf8String, -1, nil)
            if sqlite3_step(insertStatement) == SQLITE_DONE {
                print("Successfully inserted row.")
            } else {
                print("Could not insert row.")
            }
        } else {
            print("INSERT statement could not be prepared.")
        }
        sqlite3_finalize(insertStatement)
    }
    func getAllStudents() -> [StudentModel] {
        let queryStatementString = "SELECT * FROM Student;"
        var queryStatement: OpaquePointer? = nil
        var studentsArray : [StudentModel] = []
        if sqlite3_prepare_v2(db, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            while sqlite3_step(queryStatement) == SQLITE_ROW {
                let id = sqlite3_column_int(queryStatement, 0)
                let name = String(describing: String(cString: sqlite3_column_text(queryStatement, 1)))
                let year = sqlite3_column_int(queryStatement, 2)
                let batch = String(describing: String(cString: sqlite3_column_text(queryStatement, 3)))
                studentsArray.append(StudentModel(id: Int(id), name: name, age: Int(year), batch: batch))
                print("Query Result:")
                print("\(id)-\(name)-\(year)-\(batch)")
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        sqlite3_finalize(queryStatement)
        return studentsArray
    }
    func deleteStudentByID(id:Int) {
        let deleteStatementStirng = "DELETE FROM Student WHERE Id = ?;"
        var deleteStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, deleteStatementStirng, -1, &deleteStatement, nil) == SQLITE_OK {
            sqlite3_bind_int(deleteStatement, 1, Int32(id))
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Successfully deleted row.")
            } else {
                print("Could not delete row.")
            }
        } else {
            print("DELETE statement could not be prepared")
        }
        sqlite3_finalize(deleteStatement)
    }
}

