//
//  Swift_Backend_TechnologyTests.swift
//  Swift Backend TechnologyTests
//
//  Created by ABY FRANCIS on 11/05/20.
//  Copyright © 2020 Two minds Technology. All rights reserved.
//

import XCTest
@testable import Swift_Backend_Technology

class Swift_Backend_TechnologyTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
